const phrases = [
  "Build Your Digital Future",
  "Learn. Grow. Succeed.",
  "Professional Skills for a Digital World",
  "Upgrade Your Marketing Skills Today"
];

const el = document.getElementById("rotating-text");

let index = 0;

function rotateText() {
  index = (index + 1) % phrases.length;
  el.textContent = phrases[index];
}

setInterval(rotateText, 2500);
